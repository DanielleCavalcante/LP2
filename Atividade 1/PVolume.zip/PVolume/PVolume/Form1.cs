﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //limpar dados formas de limpar
            txtAltura.Clear(); //mais simples e bonito
            txtRaio.Text = " "; //coloca espaço vazio na caixa
            txtVolume.Text = String.Empty; 

            txtRaio.Focus(); //depois de limpar tudo, volta para o primeiro componente.
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double raio, altura, volume;

            if (Double.TryParse(txtAltura.Text, out altura) &&
                Double.TryParse(txtRaio.Text, out raio))
            {
                if ((altura <= 0 || (raio <= 0)))
                {
                    MessageBox.Show("Altura e raio devem ser maior que zero");
                    txtRaio.Focus();
                }

                else
                {
                    //volume =3.14 * raio * altura;
                    volume = Math.PI * Math.Pow(raio, 2) * altura; //Pow faz potenciação
                    txtVolume.Text = volume.ToString("N2"); //numero com duas casas
                }
            }

            else
            {
                MessageBox.Show("Valores inválidos");
                txtRaio.Focus();
            }
        }
    }
}
